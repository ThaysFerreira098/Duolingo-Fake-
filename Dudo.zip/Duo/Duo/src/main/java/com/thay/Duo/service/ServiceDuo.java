package com.thay.Duo.service;

import com.thay.Duo.model.Nivel1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.thay.Duo.repository.RepositoryNivel1;
import java.util.List;

@Service
public class ServiceDuo {

    @Autowired
    private RepositoryNivel1 Na1;

    public List<Nivel1> AparecerTela() {//faz parte do back-end 
        return Na1.findAll();
    }

   // busca uma pergunta específica dentro de um nível
    public Nivel1 buscarPergunta(int nivel, int tipo) {
        return Na1.findByNivelAndTipo(nivel, tipo).orElse(null);
    }

   public boolean verificarResposta(int nivel, int tipo, String opcaoEscolhida) {
    Nivel1 pergunta = Na1.findByNivelAndTipo(nivel, tipo).orElse(null);
    if (pergunta == null) return false;

    String respostaCerta = switch (pergunta.getRespostacorreta() ) {
        case 1 -> pergunta.getCompletar1();
        case 2 -> pergunta.getCompletar2();
        case 3 -> pergunta.getCompletar3();
        default -> null;
    };

    return respostaCerta != null && respostaCerta.equals(opcaoEscolhida);
}

    // conta quantas perguntas tem naquele nível, pra saber quando acabou
    public int contarPerguntas(int nivel) {
        return Na1.findByNivelOrderByTipo(nivel).size();
    }
}
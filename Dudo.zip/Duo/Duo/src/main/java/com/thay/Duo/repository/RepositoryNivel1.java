package com.thay.Duo.repository;
import com.thay.Duo.model.Nivel1;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface RepositoryNivel1 extends JpaRepository<Nivel1, Integer> {
    Optional<Nivel1> findByNivelAndTipo(int nivel, int tipo);
    List<Nivel1> findByNivelOrderByTipo(int nivel);
}
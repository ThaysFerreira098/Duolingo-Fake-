package com.thay.Duo.controller;
import com.thay.Duo.model.Nivel1;
import com.thay.Duo.service.ServiceDuo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/fases")
public class ControllerDuo {

    @Autowired
    ServiceDuo duo;

    @GetMapping
    public String Fases(Model model){
        model.addAttribute("inicio", duo.AparecerTela());
        return "paginas/inicio";
    }
@GetMapping("/nivel1")
public String mostrarPergunta(@RequestParam int nivel, @RequestParam int tipo, Model model){
    Nivel1 pergunta = duo.buscarPergunta(nivel, tipo);
    model.addAttribute("pergunta", pergunta);
    model.addAttribute("nivel", nivel);
    model.addAttribute("tipo", tipo);
    return "paginas/nivel1";
}
@PostMapping("/nivel1/responder")
public String responderNivel1(@RequestParam int nivel, @RequestParam int tipo, @RequestParam String opcaoEscolhida,@RequestParam(required = false, defaultValue = "false") boolean tempoEsgotado, Model model){
    Nivel1 pergunta = duo.buscarPergunta(nivel, tipo);
    boolean resultado = tempoEsgotado ? false : duo.verificarResposta(nivel, tipo, opcaoEscolhida);
    int totalPerguntas = duo.contarPerguntas(nivel);

    model.addAttribute("resultado", resultado);
    model.addAttribute("tempoEsgotado", tempoEsgotado);
    model.addAttribute("nivel", nivel);
    model.addAttribute("tipo", tipo);
    model.addAttribute("pergunta", pergunta);

    if (resultado && tipo + 1 < totalPerguntas) {
        model.addAttribute("proximoTipo", tipo + 1);
    } else if (resultado) {
        model.addAttribute("nivelCompleto", true);
    }

    return "paginas/nivel1";
}
}
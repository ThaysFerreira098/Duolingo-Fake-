package com.thay.Duo.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;
@Component
@Entity
public class Nivel1 {
    @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private int nivel;
    private int tipo;
    private int respostacorreta;
    private String frase1;
    private String completar1;
    private String completar2;
    private String completar3;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nivel
     */
    public int getNivel() {
        return nivel;
    }

    /**
     * @param nivel the nivel to set
     */
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    /**
     * @return the tipo
     */
    public int getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the respostacorreta
     */
    public int getRespostacorreta() {
        return respostacorreta;
    }

    /**
     * @param respostacorreta the respostacorreta to set
     */
    public void setRespostacorreta(int respostacorreta) {
        this.respostacorreta = respostacorreta;
    }

    /**
     * @return the frase1
     */
    public String getFrase1() {
        return frase1;
    }

    /**
     * @param frase1 the frase1 to set
     */
    public void setFrase1(String frase1) {
        this.frase1 = frase1;
    }

    /**
     * @return the completar1
     */
    public String getCompletar1() {
        return completar1;
    }

    /**
     * @param completar1 the completar1 to set
     */
    public void setCompletar1(String completar1) {
        this.completar1 = completar1;
    }

    /**
     * @return the completar2
     */
    public String getCompletar2() {
        return completar2;
    }

    /**
     * @param completar2 the completar2 to set
     */
    public void setCompletar2(String completar2) {
        this.completar2 = completar2;
    }

    /**
     * @return the completar3
     */
    public String getCompletar3() {
        return completar3;
    }

    /**
     * @param completar3 the completar3 to set
     */
    public void setCompletar3(String completar3) {
        this.completar3 = completar3;
    }

}

package com.thay.Duo.service;
import com.thay.Duo.model.Nivel1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.thay.Duo.repository.RepositoryNivel1;
@Service

public class ServiceDuo {
       @Autowired
  private RepositoryNivel1 Na1;
   

public boolean completar(int id, String opcaoEscolhida) {
    Nivel1 nivel = Na1.findById(id).orElse(null);
    if (nivel == null) return false;
    return nivel.getCompletar1().equals(opcaoEscolhida);
}
}

package com.thay.Duo.repository;
import com.thay.Duo.model.Nivel1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryNivel1 extends JpaRepository<Nivel1, Integer>{

}
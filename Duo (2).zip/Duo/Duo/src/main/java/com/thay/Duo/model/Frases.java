package com.thay.Duo.model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;
@Component
@Entity
public class Frases {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private String frase1;
    private String frase2;
    private String frase3;
    private String completar1;
    private String completar2;
    private String completar3;
   private String completar4;
    private String completar5;
    private String completar6;
     private String completar7;
    private String completar8;
    private String completar9;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the frase1
     */
    public String getFrase1() {
        return frase1;
    }

    /**
     * @param frase1 the frase1 to set
     */
    public void setFrase1(String frase1) {
        this.frase1 = frase1;
    }

    /**
     * @return the frase2
     */
    public String getFrase2() {
        return frase2;
    }

    /**
     * @param frase2 the frase2 to set
     */
    public void setFrase2(String frase2) {
        this.frase2 = frase2;
    }

    /**
     * @return the frase3
     */
    public String getFrase3() {
        return frase3;
    }

    /**
     * @param frase3 the frase3 to set
     */
    public void setFrase3(String frase3) {
        this.frase3 = frase3;
    }

    /**
     * @return the completar1
     */
    public String getCompletar1() {
        return completar1;
    }

    /**
     * @param completar1 the completar1 to set
     */
    public void setCompletar1(String completar1) {
        this.completar1 = completar1;
    }

    /**
     * @return the completar2
     */
    public String getCompletar2() {
        return completar2;
    }

    /**
     * @param completar2 the completar2 to set
     */
    public void setCompletar2(String completar2) {
        this.completar2 = completar2;
    }

    /**
     * @return the completar3
     */
    public String getCompletar3() {
        return completar3;
    }

    /**
     * @param completar3 the completar3 to set
     */
    public void setCompletar3(String completar3) {
        this.completar3 = completar3;
    }

    /**
     * @return the completar4
     */
    public String getCompletar4() {
        return completar4;
    }

    /**
     * @param completar4 the completar4 to set
     */
    public void setCompletar4(String completar4) {
        this.completar4 = completar4;
    }

    /**
     * @return the completar5
     */
    public String getCompletar5() {
        return completar5;
    }

    /**
     * @param completar5 the completar5 to set
     */
    public void setCompletar5(String completar5) {
        this.completar5 = completar5;
    }

    /**
     * @return the completar6
     */
    public String getCompletar6() {
        return completar6;
    }

    /**
     * @param completar6 the completar6 to set
     */
    public void setCompletar6(String completar6) {
        this.completar6 = completar6;
    }

    /**
     * @return the completar7
     */
    public String getCompletar7() {
        return completar7;
    }

    /**
     * @param completar7 the completar7 to set
     */
    public void setCompletar7(String completar7) {
        this.completar7 = completar7;
    }

    /**
     * @return the completar8
     */
    public String getCompletar8() {
        return completar8;
    }

    /**
     * @param completar8 the completar8 to set
     */
    public void setCompletar8(String completar8) {
        this.completar8 = completar8;
    }

    /**
     * @return the completar9
     */
    public String getCompletar9() {
        return completar9;
    }

    /**
     * @param completar9 the completar9 to set
     */
    public void setCompletar9(String completar9) {
        this.completar9 = completar9;
    }
    

}
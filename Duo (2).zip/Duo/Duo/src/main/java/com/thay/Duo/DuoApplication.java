package com.thay.Duo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DuoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DuoApplication.class, args);
	}

}

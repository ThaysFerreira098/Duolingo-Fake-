package com.thay.Duo.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.stereotype.Component;
@Component
@Entity
public class Nivel1 {
    @Id
    private int id;
    private String frase1;
    private String completar1;
    private String completar2;
    private String completar3;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the frase1
     */
    public String getFrase1() {
        return frase1;
    }

    /**
     * @param frase1 the frase1 to set
     */
    public void setFrase1(String frase1) {
        this.frase1 = frase1;
    }

    /**
     * @return the completar1
     */
    public String getCompletar1() {
        return completar1;
    }

    /**
     * @param completar1 the completar1 to set
     */
    public void setCompletar1(String completar1) {
        this.completar1 = completar1;
    }

    /**
     * @return the completar2
     */
    public String getCompletar2() {
        return completar2;
    }

    /**
     * @param completar2 the completar2 to set
     */
    public void setCompletar2(String completar2) {
        this.completar2 = completar2;
    }

    /**
     * @return the completar3
     */
    public String getCompletar3() {
        return completar3;
    }

    /**
     * @param completar3 the completar3 to set
     */
    public void setCompletar3(String completar3) {
        this.completar3 = completar3;
    }

}
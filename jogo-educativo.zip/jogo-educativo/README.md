# Jogo Educativo (estilo Duolingo) — Primeira Fase

Estrutura inicial do projeto, baseada no seu PDF de planejamento.

## Como rodar

1. Precisa ter **Java 17+** e **Maven** instalados.
2. Na pasta do projeto, rode:
   ```
   mvn spring-boot:run
   ```
3. Abra o navegador em: `http://localhost:8080`

O Spring Boot já serve as telas HTML da pasta `static` automaticamente —
não precisa configurar servidor web separado.

## Estrutura de pastas

```
src/main/java/com/jogoeducativo/
├── JogoEducativoApplication.java   -> classe principal (main)
├── model/
│   ├── Jogador.java                -> nome, vidas, xp
│   ├── Licao.java                  -> junta conversa + pergunta final
│   ├── FalaConversa.java           -> cada linha da "complete a conversa"
│   ├── PerguntaFinal.java          -> pergunta A/B com tempo (tela "Final jogo")
│   └── Progresso.java              -> qual lição o jogador concluiu e a nota
├── service/
│   └── ProgressoService.java       -> guarda tudo em memória por enquanto
└── controller/
    ├── JogadorController.java      -> POST /api/jogadores (tela introdução)
    └── LicaoController.java        -> GET /api/licoes/1, POST resultado

src/main/resources/static/
├── index.html         -> Tela inicial (trilha de lições)
├── introducao.html    -> Tela introdução (Bill + nome do jogador)
├── licao1.html         -> Tela de Lição 1 (completar a conversa)
├── final-fase.html    -> Tela final da fase (pergunta A/B com tempo) + desbloqueio
├── css/style.css      -> cores verde/azul, como no PDF
└── js/app.js          -> chamadas para o back-end
```

## Fluxo da primeira fase (o que já funciona)

1. `index.html` → jogador ainda não existe → manda para `introducao.html`
2. `introducao.html` → jogador digita o nome → cria o jogador no back-end → vai para `licao1.html`
3. `licao1.html` → busca a lição 1 no back-end → jogador clica nas palavras para
   completar "Hi, ___ ___?" → ao verificar, vai para `final-fase.html`
4. `final-fase.html` → mostra a pergunta sobre a conversa com timer de 60s →
   jogador escolhe A ou B → envia o resultado (nota) para o back-end →
   mostra a tela de "desbloquear próxima fase"

## O que ainda falta (próximos passos sugeridos)

- **Lição 2** ("escrever" a frase do zero, como no PDF) — dá pra copiar o
  padrão de `LicaoController.licao1()` e criar `licao2()`, e uma tela
  `licao2.html` parecida.
- **Persistir de verdade**: hoje `ProgressoService` guarda tudo em memória
  (some quando reiniciar o servidor). Trocar por banco de dados (H2 para
  testar local, ou MySQL/MariaDB) usando Spring Data JPA.
- **Tela "conversar" vs "evoluir nível"**: o PDF mostra duas opções na tela
  de desbloqueio — hoje só tem um botão de voltar pra trilha; dá pra
  decidir o que cada uma faz e implementar depois.
- **Áudio**: o ícone de fone de ouvido na tela inicial sugere lições de
  escuta — ainda não implementado.
- **Trilha com bloqueio real**: hoje todas as lições aparecem "disponíveis";
  falta usar o `Progresso` para bloquear lições seguintes até a anterior
  ser concluída.

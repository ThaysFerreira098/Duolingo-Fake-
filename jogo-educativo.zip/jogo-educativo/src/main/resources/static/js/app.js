// Funções compartilhadas por todas as telas.
// Guardamos o id do jogador no localStorage depois da tela de
// introdução, para não pedir o nome de novo a cada tela.

function salvarJogadorId(id) {
  localStorage.setItem('jogadorId', id);
}

function obterJogadorId() {
  return localStorage.getItem('jogadorId');
}

async function criarJogador(nome) {
  const resposta = await fetch('/api/jogadores', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome }),
  });
  return resposta.json();
}

async function buscarLicao(id) {
  const resposta = await fetch(`/api/licoes/${id}`);
  return resposta.json();
}

async function enviarResultadoLicao(licaoId, jogadorId, concluida, nota) {
  const resposta = await fetch(`/api/licoes/${licaoId}/resultado`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jogadorId: Number(jogadorId), concluida, nota }),
  });
  return resposta.json();
}

async function buscarProgresso(jogadorId) {
  // Endpoint simples ainda não existe no back-end para listar
  // progresso por jogador — retorna vazio por enquanto.
  // Dá pra criar um GET /api/jogadores/{id}/progresso depois.
  return [];
}

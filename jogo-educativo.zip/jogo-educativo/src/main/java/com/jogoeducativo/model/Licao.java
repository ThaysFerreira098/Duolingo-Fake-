package com.jogoeducativo.model;

import java.util.List;

/**
 * Uma lição da trilha (os círculos azuis da "Tela inicial" do PDF).
 * Junta a conversa a ser completada e a pergunta final da fase.
 */
public class Licao {

    private Long id;
    private String titulo;
    private List<FalaConversa> conversa;
    private PerguntaFinal perguntaFinal;

    public Licao() {
    }

    public Licao(Long id, String titulo, List<FalaConversa> conversa, PerguntaFinal perguntaFinal) {
        this.id = id;
        this.titulo = titulo;
        this.conversa = conversa;
        this.perguntaFinal = perguntaFinal;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<FalaConversa> getConversa() {
        return conversa;
    }

    public void setConversa(List<FalaConversa> conversa) {
        this.conversa = conversa;
    }

    public PerguntaFinal getPerguntaFinal() {
        return perguntaFinal;
    }

    public void setPerguntaFinal(PerguntaFinal perguntaFinal) {
        this.perguntaFinal = perguntaFinal;
    }
}

package com.jogoeducativo.model;

import java.util.List;

/**
 * Uma linha de diálogo dentro da tela "complete a conversa"
 * (Tela de Lição 1 do PDF). Cada fala é de um personagem
 * (a "pessoa" do jogo ou o "jogador") e pode ter uma lacuna
 * para o jogador preencher escolhendo entre as opções.
 */
public class FalaConversa {

    public enum Personagem {
        PESSOA,
        JOGADOR
    }

    private Personagem personagem;
    private String textoComLacuna; // ex: "Hi, ___ ___?"
    private List<String> opcoes;   // ex: ["are", "what"] - banco de palavras
    private List<String> respostaCorreta; // ex: ["are", "what"]

    public FalaConversa() {
    }

    public FalaConversa(Personagem personagem, String textoComLacuna,
                         List<String> opcoes, List<String> respostaCorreta) {
        this.personagem = personagem;
        this.textoComLacuna = textoComLacuna;
        this.opcoes = opcoes;
        this.respostaCorreta = respostaCorreta;
    }

    public Personagem getPersonagem() {
        return personagem;
    }

    public void setPersonagem(Personagem personagem) {
        this.personagem = personagem;
    }

    public String getTextoComLacuna() {
        return textoComLacuna;
    }

    public void setTextoComLacuna(String textoComLacuna) {
        this.textoComLacuna = textoComLacuna;
    }

    public List<String> getOpcoes() {
        return opcoes;
    }

    public void setOpcoes(List<String> opcoes) {
        this.opcoes = opcoes;
    }

    public List<String> getRespostaCorreta() {
        return respostaCorreta;
    }

    public void setRespostaCorreta(List<String> respostaCorreta) {
        this.respostaCorreta = respostaCorreta;
    }
}

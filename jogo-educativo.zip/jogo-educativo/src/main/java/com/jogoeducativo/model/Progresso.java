package com.jogoeducativo.model;

/**
 * Classe intermediária que guarda qual lição o jogador já concluiu
 * e sua nota — exatamente a ideia anotada no PDF de planejamento.
 * É o que faz os círculos da trilha (Tela inicial) aparecerem
 * com o "check" azul em vez de bloqueados.
 */
public class Progresso {

    private Long jogadorId;
    private Long licaoId;
    private boolean concluida;
    private double nota; // 0 a 10, por exemplo

    public Progresso() {
    }

    public Progresso(Long jogadorId, Long licaoId, boolean concluida, double nota) {
        this.jogadorId = jogadorId;
        this.licaoId = licaoId;
        this.concluida = concluida;
        this.nota = nota;
    }

    public Long getJogadorId() {
        return jogadorId;
    }

    public void setJogadorId(Long jogadorId) {
        this.jogadorId = jogadorId;
    }

    public Long getLicaoId() {
        return licaoId;
    }

    public void setLicaoId(Long licaoId) {
        this.licaoId = licaoId;
    }

    public boolean isConcluida() {
        return concluida;
    }

    public void setConcluida(boolean concluida) {
        this.concluida = concluida;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }
}

package com.jogoeducativo.model;

/**
 * Representa o jogador (aluno) dentro do jogo.
 * Guarda o nome informado na tela de introdução e o "coração"
 * (vidas) que aparece no canto da tela de lição, como no PDF.
 */
public class Jogador {

    private Long id;
    private String nome;
    private int vidas = 5;
    private int xp = 0;

    public Jogador() {
    }

    public Jogador(Long id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
        this.vidas = vidas;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }
}

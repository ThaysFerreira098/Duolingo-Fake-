package com.jogoeducativo.model;

/**
 * Pergunta da tela "Final jogo" do PDF: recapitula a conversa
 * da lição e o jogador escolhe entre A ou B, com tempo limite.
 */
public class PerguntaFinal {

    private String pergunta;
    private String opcaoA;
    private String opcaoB;
    private String respostaCorreta; // "A" ou "B"
    private int tempoSegundos = 60;

    public PerguntaFinal() {
    }

    public PerguntaFinal(String pergunta, String opcaoA, String opcaoB,
                          String respostaCorreta, int tempoSegundos) {
        this.pergunta = pergunta;
        this.opcaoA = opcaoA;
        this.opcaoB = opcaoB;
        this.respostaCorreta = respostaCorreta;
        this.tempoSegundos = tempoSegundos;
    }

    public String getPergunta() {
        return pergunta;
    }

    public void setPergunta(String pergunta) {
        this.pergunta = pergunta;
    }

    public String getOpcaoA() {
        return opcaoA;
    }

    public void setOpcaoA(String opcaoA) {
        this.opcaoA = opcaoA;
    }

    public String getOpcaoB() {
        return opcaoB;
    }

    public void setOpcaoB(String opcaoB) {
        this.opcaoB = opcaoB;
    }

    public String getRespostaCorreta() {
        return respostaCorreta;
    }

    public void setRespostaCorreta(String respostaCorreta) {
        this.respostaCorreta = respostaCorreta;
    }

    public int getTempoSegundos() {
        return tempoSegundos;
    }

    public void setTempoSegundos(int tempoSegundos) {
        this.tempoSegundos = tempoSegundos;
    }
}

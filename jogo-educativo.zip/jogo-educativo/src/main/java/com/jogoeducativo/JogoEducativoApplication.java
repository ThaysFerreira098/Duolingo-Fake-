package com.jogoeducativo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada do jogo.
 * Ao rodar essa classe, o Spring Boot sobe um servidor web em
 * http://localhost:8080 e já serve as telas HTML da pasta
 * src/main/resources/static automaticamente.
 */
@SpringBootApplication
public class JogoEducativoApplication {

    public static void main(String[] args) {
        SpringApplication.run(JogoEducativoApplication.class, args);
    }
}

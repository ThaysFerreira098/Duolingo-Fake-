package com.jogoeducativo.controller;

import com.jogoeducativo.model.FalaConversa;
import com.jogoeducativo.model.FalaConversa.Personagem;
import com.jogoeducativo.model.Licao;
import com.jogoeducativo.model.PerguntaFinal;
import com.jogoeducativo.model.Progresso;
import com.jogoeducativo.service.ProgressoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Serve os dados da(s) lição(ões) para as telas em HTML/JS e
 * recebe o resultado quando o jogador termina uma lição.
 *
 * Por enquanto só existe a Lição 1, seguindo o exemplo do PDF
 * ("Hi, ___ ___?" -> "Hi, what are..."). Quando quiser adicionar
 * a Lição 2 (a de "escrever"), é só criar outro método parecido
 * com licao1() e outro id.
 */
@RestController
@RequestMapping("/api/licoes")
public class LicaoController {

    private final ProgressoService progressoService;

    public LicaoController(ProgressoService progressoService) {
        this.progressoService = progressoService;
    }

    @GetMapping("/{id}")
    public Licao buscarLicao(@PathVariable Long id) {
        // Por enquanto só temos a lição 1 cadastrada "na mão".
        // Depois isso pode virar uma lista/banco de dados.
        return licao1();
    }

    private Licao licao1() {
        FalaConversa fala1 = new FalaConversa(
                Personagem.PESSOA,
                "Hi",
                List.of(),
                List.of()
        );

        FalaConversa fala2 = new FalaConversa(
                Personagem.JOGADOR,
                "Hi, ___ ___?",
                List.of("are", "what"),
                List.of("what", "are")
        );

        PerguntaFinal perguntaFinal = new PerguntaFinal(
                "Qual era o assunto da conversa?",
                "Uma saudação",
                "O clima",
                "A",
                60
        );

        return new Licao(1L, "Lição 1 - Cumprimentos", List.of(fala1, fala2), perguntaFinal);
    }

    public record ResultadoLicaoRequest(Long jogadorId, boolean concluida, double nota) {
    }

    @PostMapping("/{id}/resultado")
    public Progresso enviarResultado(@PathVariable Long id, @RequestBody ResultadoLicaoRequest request) {
        return progressoService.salvarProgresso(request.jogadorId(), id, request.concluida(), request.nota());
    }
}

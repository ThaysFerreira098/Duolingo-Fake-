package com.jogoeducativo.controller;

import com.jogoeducativo.model.Jogador;
import com.jogoeducativo.service.ProgressoService;
import org.springframework.web.bind.annotation.*;

/**
 * Atende a tela de introdução: quando o jogador digita o nome
 * e clica em "Próximo", o front-end chama POST /api/jogadores.
 */
@RestController
@RequestMapping("/api/jogadores")
public class JogadorController {

    private final ProgressoService progressoService;

    public JogadorController(ProgressoService progressoService) {
        this.progressoService = progressoService;
    }

    public record NovoJogadorRequest(String nome) {
    }

    @PostMapping
    public Jogador criar(@RequestBody NovoJogadorRequest request) {
        return progressoService.criarJogador(request.nome());
    }

    @GetMapping("/{id}")
    public Jogador buscar(@PathVariable Long id) {
        return progressoService.buscarJogador(id);
    }
}

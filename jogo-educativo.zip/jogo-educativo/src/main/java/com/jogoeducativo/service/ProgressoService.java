package com.jogoeducativo.service;

import com.jogoeducativo.model.Jogador;
import com.jogoeducativo.model.Progresso;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * Guarda jogadores e progresso em memória (sem banco de dados
 * ainda). Serve como ponto único para trocar por um banco de
 * verdade (JPA + H2/MySQL) mais pra frente, sem mudar os
 * controllers.
 */
@Service
public class ProgressoService {

    private final Map<Long, Jogador> jogadores = new ConcurrentHashMap<>();
    private final Map<Long, Progresso> progressos = new ConcurrentHashMap<>();
    private final AtomicLong proximoIdJogador = new AtomicLong(1);
    private final AtomicLong proximoIdProgresso = new AtomicLong(1);

    public Jogador criarJogador(String nome) {
        long id = proximoIdJogador.getAndIncrement();
        Jogador jogador = new Jogador(id, nome);
        jogadores.put(id, jogador);
        return jogador;
    }

    public Jogador buscarJogador(Long id) {
        return jogadores.get(id);
    }

    public Progresso salvarProgresso(Long jogadorId, Long licaoId, boolean concluida, double nota) {
        Progresso progresso = new Progresso(jogadorId, licaoId, concluida, nota);
        progressos.put(proximoIdProgresso.getAndIncrement(), progresso);
        return progresso;
    }

    public List<Progresso> progressoDoJogador(Long jogadorId) {
        return progressos.values().stream()
                .filter(p -> p.getJogadorId().equals(jogadorId))
                .collect(Collectors.toList());
    }
}
